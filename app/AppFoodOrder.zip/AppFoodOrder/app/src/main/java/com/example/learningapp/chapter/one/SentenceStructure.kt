package com.example.learningapp.chapter.one

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.learningapp.R
import com.google.firebase.firestore.FirebaseFirestore
import android.view.View
import android.content.Intent
import com.example.learningapp.ResultsActivity

class SentenceStructure : AppCompatActivity() {

    private lateinit var questionView: TextView
    private lateinit var radioGroupOptions: RadioGroup
    private lateinit var nextButton: Button

    private lateinit var db: FirebaseFirestore
    private var questionList: List<Map<String, Any>> = emptyList()
    private var currentQuestionIndex = 0
    private var correctAnswersCount = 0
    private var username: String = "Người dùng"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sentence_structure)


        val sharedPref = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
        username = sharedPref.getString("USERNAME", "Người dùng") ?: username

        questionView = findViewById(R.id.text_question)
        radioGroupOptions = findViewById(R.id.radio_group_options)
        nextButton = findViewById(R.id.btn_next)

        db = FirebaseFirestore.getInstance()

        loadQuestionsFromFirestore()

        nextButton.setOnClickListener {
            val selectedRadioButtonId = radioGroupOptions.checkedRadioButtonId
            if (selectedRadioButtonId == -1) {
                Toast.makeText(this, "Vui lòng chọn một đáp án", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val selectedRadioButton = findViewById<RadioButton>(selectedRadioButtonId)
            val selectedAnswer = selectedRadioButton.text.toString()
            val correctAnswer = questionList[currentQuestionIndex]["answer"] as? String

            if (selectedAnswer == correctAnswer) {
                correctAnswersCount++
            }

            if (currentQuestionIndex < questionList.size - 1) {
                currentQuestionIndex++
                displayQuestion()
            } else {
                saveResultToFirestore()
                Toast.makeText(
                    this,
                    "Bạn đã hoàn thành: $correctAnswersCount / ${questionList.size}",
                    Toast.LENGTH_LONG
                ).show()
                nextButton.isEnabled = false
            }
        }
    }

    private fun loadQuestionsFromFirestore() {
        db.collection("quizzes")
            .document("SentenceStructure")
            .get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    Log.d("Firestore", "Tải dữ liệu thành công")

                    questionList = (document.data?.values?.toList() as? List<Map<String, Any>>)
                        ?.sortedBy { it["id"]?.toString()?.toIntOrNull() ?: 0 } ?: emptyList()

                    if (questionList.isNotEmpty()) {
                        correctAnswersCount = 0
                        currentQuestionIndex = 0
                        displayQuestion()
                    } else {
                        questionView.text = "Không có câu hỏi nào"
                    }
                } else {
                    questionView.text = "Không tìm thấy dữ liệu"
                }
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Lỗi: ${e.message}", e)
                questionView.text = "Lỗi khi tải dữ liệu"
            }
    }

    private fun displayQuestion() {
        val questionData = questionList[currentQuestionIndex]
        val question = questionData["question"] as? String ?: "Câu hỏi không hợp lệ"
        val options = questionData["options"] as? Map<String, String> ?: emptyMap()

        questionView.text = "Câu ${currentQuestionIndex + 1}: $question"
        radioGroupOptions.removeAllViews()

        for ((_, value) in options.entries.sortedBy { it.key }) {
            val radioButton = RadioButton(this)
            radioButton.text = value
            radioButton.id = View.generateViewId()
            radioGroupOptions.addView(radioButton)
        }
    }

    private fun saveResultToFirestore() {
        val result = hashMapOf(
            "username" to username,
            "score" to correctAnswersCount,
            "total" to questionList.size,
            "timestamp" to System.currentTimeMillis()
        )

        db.collection("results")
            .add(result)
            .addOnSuccessListener {
                Log.d("Firestore", "Kết quả đã được lưu")

                val intent = Intent(this, ResultsActivity::class.java)
                intent.putExtra("SCORE", correctAnswersCount)
                intent.putExtra("TOTAL", questionList.size)
                intent.putExtra("USERNAME", username)
                startActivity(intent)
                finish() // Đảm bảo đóng màn hình cũ
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Lỗi lưu kết quả: ${e.message}", e)
                Toast.makeText(this, "Lỗi khi lưu kết quả", Toast.LENGTH_SHORT).show()
            }
    }
}
